"""Bounded, single-flight PyJWT JWKS refreshes for origin verifiers."""

from __future__ import annotations

from collections.abc import Callable
from threading import Lock
from time import monotonic
from typing import Any

import jwt
from jwt.exceptions import PyJWKClientError


class RateLimitedJWKClient:
    """Cache one JWKS snapshot and bound refreshes caused by unknown keys."""

    def __init__(
        self,
        inner: Any,
        *,
        lifespan: float = 300,
        refresh_cooldown: float = 30,
        clock: Callable[[], float] = monotonic,
    ) -> None:
        self._inner = inner
        self._lifespan = lifespan
        self._refresh_cooldown = refresh_cooldown
        self._clock = clock
        self._keys: dict[str, Any] = {}
        self._snapshot_expires_at = 0.0
        self._refresh_not_before = 0.0
        self._lock = Lock()

    def get_signing_key_from_jwt(self, token: str) -> Any:
        header = jwt.get_unverified_header(token)
        kid = header.get("kid")
        if not isinstance(kid, str) or not kid:
            raise PyJWKClientError("identity assertion has no key identifier")

        now = self._clock()
        cached = self._cached(kid, now)
        if cached is not None:
            return cached
        if not self._lock.acquire(blocking=False):
            raise PyJWKClientError("JWKS refresh is already in progress")
        try:
            now = self._clock()
            cached = self._cached(kid, now)
            if cached is not None:
                return cached

            snapshot_fresh = now < self._snapshot_expires_at
            if now < self._refresh_not_before:
                raise PyJWKClientError("JWKS refresh is cooling down")
            self._refresh_not_before = now + self._refresh_cooldown
            # Build a replacement before publishing it. On fetch/parse failure,
            # a still-fresh prior snapshot remains usable while the cooldown
            # prevents a random-kid flood from starting another network call.
            keys = self._inner.get_signing_keys(refresh=snapshot_fresh)
            loaded: dict[str, Any] = {}
            for key in keys:
                key_id = getattr(key, "key_id", None)
                if not isinstance(key_id, str) or not key_id:
                    continue
                if key_id in loaded:
                    raise PyJWKClientError("JWKS contains duplicate key identifiers")
                loaded[key_id] = key
            if not loaded:
                raise PyJWKClientError("JWKS contains no signing keys")
            self._keys = loaded
            self._snapshot_expires_at = self._clock() + self._lifespan
            try:
                return loaded[kid]
            except KeyError:
                raise PyJWKClientError(
                    "identity assertion signing key is unknown"
                ) from None
        finally:
            self._lock.release()

    def _cached(self, kid: str, now: float) -> Any | None:
        if now >= self._snapshot_expires_at:
            return None
        return self._keys.get(kid)
