"""Tenant-pinned native HTTP/MCP owners; no trusted dispatcher escape."""

from __future__ import annotations

import asyncio
import json
import os
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from archetype.api import ServerConfig, create_app
from archetype.api.config import Grant
from archetype.api.principals import AuthenticationError, Principal
from starlette.datastructures import Headers

from vangelis_gateway.identity import PrincipalGrant
from vangelis_gateway.tenancy import require_safe_tenant_id

VIEWER = frozenset({"programs:read", "simulation:read", "artifacts:read"})
PLAYER = VIEWER | {"simulation:submit", "artifacts:publish"}
OPERATOR = PLAYER | {
    "programs:create",
    "simulation:control",
    "simulation:publish",
    "simulation:confirm",
    "simulation:restore",
    "simulation:fork",
}
ADMIN = OPERATOR | {"simulation:create"}
ROLE_CAPABILITIES = {"viewer": VIEWER, "player": PLAYER, "operator": OPERATOR, "admin": ADMIN}


def capabilities(grant):
    return frozenset().union(*(ROLE_CAPABILITIES[role] for role in grant.roles))


@dataclass(frozen=True)
class TenantVerifier:
    verifier: Any
    mappings: Any
    tenant_id: str
    namespace: str
    configured: bool = True

    def authenticate(self, credential):
        try:
            principal = self.verifier.authenticate(
                Headers(
                    {"authorization": "Bearer " + credential, "cf-access-jwt-assertion": credential}
                )
            )
            grant = self.mappings.resolve(principal)
            if (grant.tenant_id, grant.storage_namespace) != (self.tenant_id, self.namespace):
                raise AuthenticationError("principal outside tenant scope")
            return Principal(grant.actor_id, capabilities(grant))
        except AuthenticationError:
            raise
        except Exception:
            raise AuthenticationError("invalid credential") from None


@dataclass
class Entry:
    namespace: str
    app: Any
    ready: asyncio.Future
    requests: asyncio.Queue
    task: asyncio.Task | None = None
    closing: bool = False
    close_future: asyncio.Future | None = None


async def supervise(entry):
    """The SDK lifespan is entered and exited by this same retained task."""
    lifespan = entry.app.router.lifespan_context(entry.app)
    entered = False
    try:
        try:
            await lifespan.__aenter__()
            entered = True
            entry.ready.set_result(None)
        except Exception as error:
            entry.ready.set_exception(error)
        while True:
            reply = await entry.requests.get()
            try:
                await entry.app.state.aclose()
            except Exception as error:
                # Native close failed. Keep this SDK scope, owner and task alive
                # until a later shutdown request retries that same owner.
                reply.set_exception(error)
                continue
            if entered:
                try:
                    await lifespan.__aexit__(None, None, None)
                except BaseException as error:
                    entered = False
                    reply.set_exception(error)
                    raise
                entered = False
            reply.set_result(None)
            return
    finally:
        if entered:
            await lifespan.__aexit__(None, None, None)


class TenantRuntimeRegistry:
    """One server owner per immutable tenant namespace, with retryable eviction."""

    def __init__(
        self,
        *,
        base_storage_uri,
        verifier,
        mappings,
        template: ServerConfig,
        audit_storage_uri=None,
        max_active=4,
        app_factory=create_app,
    ):
        if type(max_active) is not int or max_active < 1:
            raise ValueError("max_active must be positive")
        self._root = Path(base_storage_uri).expanduser().resolve()
        self._audit = Path(audit_storage_uri or str(self._root) + "_audit").expanduser().resolve()
        self._verifier, self._mappings, self._template = verifier, mappings, template
        self._max_active, self._factory = max_active, app_factory
        self._entries = OrderedDict()
        self._bindings, self._namespaces = {}, {}
        self._lock = asyncio.Lock()

    @classmethod
    def from_env(cls, *, verifier, mappings):
        return cls(
            base_storage_uri=os.environ.get("GATEWAY_STORAGE_URI", "./archetype_native"),
            audit_storage_uri=os.environ.get("GATEWAY_AUDIT_URI"),
            max_active=int(os.environ.get("GATEWAY_MAX_ACTIVE_TENANTS", "4")),
            verifier=verifier,
            mappings=mappings,
            template=ServerConfig.from_env(),
        )

    def storage_for(self, namespace):
        return self._root / require_safe_tenant_id(namespace) / "storage"

    def audit_storage_for(self, namespace):
        return self._audit / require_safe_tenant_id(namespace) / "requests.jsonl"

    def _configuration(self, grant):
        namespace = require_safe_tenant_id(grant.storage_namespace)
        values = dict(self._template.native)
        values["store"] = str(self.storage_for(namespace))
        if values["driver"] is not None:
            values["registry"] = str(self._root / namespace / "registry")
            values["builds"] = str(self._root / namespace / "builds")
        grants = tuple(
            Grant(entry.actor_id, resource.name, capabilities(entry))
            for entry in self._mappings.grants
            if entry.tenant_id == grant.tenant_id
            for resource in self._template.resources
        )
        return ServerConfig(tuple(values.items()), self._template.resources, grants)

    async def _close(self, entry):
        entry.closing = True
        if entry.task.done():
            entry.task.result()
            return
        # Caller cancellation leaves one retained close request. A later caller
        # joins it instead of queueing an orphan after this supervisor exits.
        reply = entry.close_future
        if reply is None or (reply.done() and reply.exception() is not None):
            reply = asyncio.get_running_loop().create_future()
            reply.add_done_callback(lambda done: None if done.cancelled() else done.exception())
            entry.close_future = reply
            await entry.requests.put(reply)
        await asyncio.shield(reply)
        await asyncio.shield(entry.task)

    async def app_for(self, grant: PrincipalGrant):
        async with self._lock:
            prior = self._bindings.get(grant.tenant_id)
            if prior is not None and prior != grant.storage_namespace:
                raise RuntimeError("one tenant cannot change its storage namespace")
            tenant = self._namespaces.get(grant.storage_namespace)
            if tenant is not None and tenant != grant.tenant_id:
                raise RuntimeError("one namespace cannot serve different tenants")
            self._bindings[grant.tenant_id] = grant.storage_namespace
            self._namespaces[grant.storage_namespace] = grant.tenant_id
            entry = self._entries.get(grant.tenant_id)
            if entry is not None and entry.closing:
                await self._close(entry)
                del self._entries[grant.tenant_id]
                entry = None
            if entry is not None:
                self._entries.move_to_end(grant.tenant_id)
                await asyncio.shield(entry.ready)
                return entry.app
            while len(self._entries) >= self._max_active:
                tenant_id, entry = next(iter(self._entries.items()))
                await self._close(entry)
                del self._entries[tenant_id]
            app = self._factory(
                config=self._configuration(grant),
                verifier=TenantVerifier(
                    self._verifier, self._mappings, grant.tenant_id, grant.storage_namespace
                ),
            )
            entry = Entry(
                grant.storage_namespace,
                app,
                asyncio.get_running_loop().create_future(),
                asyncio.Queue(),
            )
            self._entries[grant.tenant_id] = entry
            entry.task = asyncio.create_task(supervise(entry))
            try:
                await asyncio.shield(entry.ready)
            except asyncio.CancelledError:
                # Request cancellation does not cancel the process owner opening.
                raise
            except Exception:
                entry.closing = True
                raise
            return app

    def audit(self, grant, *, operation, resource, status):
        """Tenant-pinned transport audit; it is not a native admission ledger."""
        path = self.audit_storage_for(grant.storage_namespace)
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        line = (
            json.dumps(
                {
                    "version": 1,
                    "actor_id": grant.actor_id,
                    "tenant_id": grant.tenant_id,
                    "operation": operation,
                    "resource": resource,
                    "http_status": status,
                },
                sort_keys=True,
            )
            + "\n"
        )
        fd = os.open(
            path, os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600
        )
        try:
            os.write(fd, line.encode())
            os.fsync(fd)
        finally:
            os.close(fd)

    async def shutdown(self):
        async with self._lock:
            while self._entries:
                tenant, entry = next(iter(self._entries.items()))
                await self._close(entry)
                del self._entries[tenant]
