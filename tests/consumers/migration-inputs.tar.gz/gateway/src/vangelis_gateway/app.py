"""Verified issuer mappings select tenant-pinned native HTTP/MCP servers."""

from __future__ import annotations

import json
from contextlib import asynccontextmanager

from starlette.applications import Starlette
from starlette.concurrency import run_in_threadpool
from starlette.datastructures import Headers
from starlette.responses import JSONResponse
from starlette.routing import Mount

from vangelis_gateway.identity import identity_components_from_env, PrincipalMappings


def create_gateway_app(verifier=None, mappings=None, registry=None):
    from vangelis_gateway.tenancy_runtime import TenantRuntimeRegistry

    if verifier is None:
        verifier, selected = identity_components_from_env()
        mappings = selected if mappings is None else mappings
    mappings = PrincipalMappings.from_env() if mappings is None else mappings
    mappings.require_issuer(verifier.issuer)
    registry = registry or TenantRuntimeRegistry.from_env(verifier=verifier, mappings=mappings)

    async def dispatch(scope, receive, send):
        if scope["type"] != "http":
            return
        headers = Headers(scope=scope)
        try:
            principal = await run_in_threadpool(verifier.authenticate, headers)
        except Exception:
            await JSONResponse(
                {"detail": "Invalid authentication credential"},
                status_code=401,
                headers={"Cache-Control": "no-store"},
            )(scope, receive, send)
            return
        try:
            grant = mappings.resolve(principal)
        except LookupError:
            await JSONResponse(
                {"detail": "Principal is not admitted"},
                status_code=403,
                headers={"Cache-Control": "no-store"},
            )(scope, receive, send)
            return
        tenant = await registry.app_for(grant)
        # A verified Access assertion becomes the same credential at the native
        # verifier boundary; no role/actor headers or trusted commands are added.
        token = headers.get("cf-access-jwt-assertion")
        if token:
            scope = dict(
                scope,
                headers=[(k, v) for k, v in scope["headers"] if k.lower() != b"authorization"]
                + [(b"authorization", ("Bearer " + token).encode())],
            )
        audit = {"operation": None, "resource": None}

        async def received():
            message = await receive()
            if message.get("body") and len(message["body"]) <= 65536:
                try:
                    raw = json.loads(message["body"])
                    if type(raw) is dict:
                        for name in audit:
                            if type(raw.get(name)) is str and len(raw[name]) <= 128:
                                audit[name] = raw[name]
                except (ValueError, UnicodeError):
                    pass
            return message

        async def sent(message):
            if message["type"] == "http.response.start":
                message = dict(
                    message,
                    headers=list(message.get("headers", [])) + [(b"cache-control", b"no-store")],
                )
                await run_in_threadpool(
                    registry.audit,
                    grant,
                    operation=audit["operation"],
                    resource=audit["resource"],
                    status=message["status"],
                )
            await send(message)

        await tenant(scope, received, sent)

    @asynccontextmanager
    async def lifespan(app):
        try:
            yield
        finally:
            await registry.shutdown()

    app = Starlette(routes=[Mount("/", app=dispatch)], lifespan=lifespan)
    app.state.tenant_registry = registry
    return app
