"""Cloudflare Access identity-assertion verification.

The validation contract follows Cloudflare's canonical example and adds a
human-only claim profile for the Lake OS private alpha:
https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/validating-json/
"""

from __future__ import annotations

import os
import re
from collections.abc import Mapping
from typing import Any

import jwt
from jwt import InvalidTokenError, PyJWKClient
from jwt.exceptions import PyJWKClientError

from vangelis_gateway._jwks import RateLimitedJWKClient
from vangelis_gateway.identity import (
    ExternalPrincipal,
    HeaderSource,
    IdentityVerificationError,
)

ACCESS_ASSERTION_HEADER = "Cf-Access-Jwt-Assertion"
_ALLOWED_ALGORITHMS = ["RS256"]
_MAX_ASSERTION_BYTES = 16_384
_TEAM_DOMAIN_RE = re.compile(
    r"(?=.{1,253}\Z)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+"
    r"[A-Za-z]{2,63}\Z"
)


class CloudflareAccessVerifier:
    """Validate a human Cloudflare Access application token against team JWKS."""

    def __init__(
        self,
        *,
        issuer: str,
        audience: str,
        jwks_url: str | None = None,
        leeway_seconds: float = 5.0,
        jwk_client: Any | None = None,
    ) -> None:
        if not issuer.startswith("https://") or issuer.endswith("/"):
            raise ValueError(
                "issuer must be an exact HTTPS origin without a trailing slash"
            )
        if not audience or audience != audience.strip():
            raise ValueError("audience must be a non-empty trimmed string")
        if jwk_client is None:
            if not jwks_url:
                raise ValueError("either jwks_url or jwk_client is required")
            jwk_client = RateLimitedJWKClient(
                PyJWKClient(
                    jwks_url,
                    cache_keys=False,
                    cache_jwk_set=True,
                    lifespan=300,
                    timeout=5,
                )
            )
        self._issuer = issuer
        self._audience = audience
        self._jwks = jwk_client
        self._leeway = leeway_seconds

    @property
    def issuer(self) -> str:
        return self._issuer

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> CloudflareAccessVerifier:
        env = os.environ if env is None else env
        missing = [
            key
            for key in ("CLOUDFLARE_ACCESS_TEAM_DOMAIN", "CLOUDFLARE_ACCESS_AUD")
            if not env.get(key)
        ]
        if missing:
            raise RuntimeError(
                f"missing required environment variables: {', '.join(missing)}"
            )
        team_domain = env["CLOUDFLARE_ACCESS_TEAM_DOMAIN"]
        if team_domain != team_domain.strip() or not _TEAM_DOMAIN_RE.fullmatch(
            team_domain
        ):
            raise RuntimeError(
                "invalid CLOUDFLARE_ACCESS_TEAM_DOMAIN: expected a bare DNS hostname"
            )
        if not team_domain.lower().endswith(".cloudflareaccess.com"):
            raise RuntimeError(
                "invalid CLOUDFLARE_ACCESS_TEAM_DOMAIN: expected a Cloudflare Access team domain"
            )
        issuer = f"https://{team_domain.lower()}"
        return cls(
            issuer=issuer,
            audience=env["CLOUDFLARE_ACCESS_AUD"],
            jwks_url=f"{issuer}/cdn-cgi/access/certs",
        )

    def authenticate(self, headers: HeaderSource) -> ExternalPrincipal:
        values = headers.getlist(ACCESS_ASSERTION_HEADER)
        if len(values) != 1:
            raise IdentityVerificationError("exactly one Access assertion is required")
        token = values[0]
        if (
            not token
            or token != token.strip()
            or "," in token
            or len(token.encode("utf-8")) > _MAX_ASSERTION_BYTES
        ):
            raise IdentityVerificationError("invalid Access assertion header")
        return self.verify(token)

    def verify(self, token: str) -> ExternalPrincipal:
        try:
            header = jwt.get_unverified_header(token)
        except InvalidTokenError as error:
            raise IdentityVerificationError("malformed Access assertion") from error
        if header.get("alg") != "RS256":
            raise IdentityVerificationError("disallowed Access assertion algorithm")
        if header.get("typ") not in (None, "JWT"):
            raise IdentityVerificationError("invalid Access assertion type header")
        kid = header.get("kid")
        if not isinstance(kid, str) or not kid:
            raise IdentityVerificationError("Access assertion has no key identifier")

        try:
            key = self._jwks.get_signing_key_from_jwt(token)
        except Exception as error:
            raise IdentityVerificationError(
                "Access signing key is unavailable"
            ) from error
        try:
            claims = jwt.decode(
                token,
                getattr(key, "key", key),
                algorithms=_ALLOWED_ALGORITHMS,
                issuer=self._issuer,
                audience=self._audience,
                leeway=self._leeway,
                options={
                    "require": ["iss", "aud", "sub", "exp", "iat", "nbf", "type"],
                    "verify_aud": True,
                    "verify_iat": True,
                    "verify_nbf": True,
                    "verify_exp": True,
                },
            )
        except (InvalidTokenError, PyJWKClientError) as error:
            raise IdentityVerificationError(
                "Access assertion verification failed"
            ) from error

        subject = claims.get("sub")
        if not isinstance(subject, str) or not subject:
            raise IdentityVerificationError("Access subject must be a non-empty string")
        if claims.get("type") != "app":
            raise IdentityVerificationError(
                "Access assertion is not a human application token"
            )
        audiences = claims.get("aud")
        if not isinstance(audiences, list) or audiences != [self._audience]:
            raise IdentityVerificationError(
                "Access audience must use the application-token shape"
            )
        for name in ("exp", "iat", "nbf"):
            value = claims.get(name)
            if isinstance(value, bool) or not isinstance(value, int):
                raise IdentityVerificationError(f"Access {name} must be an integer")
        return ExternalPrincipal(
            issuer=self._issuer,
            subject=subject,
            claims=claims,
        )


__all__ = ["ACCESS_ASSERTION_HEADER", "CloudflareAccessVerifier"]
