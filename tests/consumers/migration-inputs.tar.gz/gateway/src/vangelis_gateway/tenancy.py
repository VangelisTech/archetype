"""Validation for server-owned tenant/storage namespaces.

Archetype validates namespaces as a single path segment matching
``[A-Za-z0-9][A-Za-z0-9_.-]*`` (``archetype.core.paths.require_safe_namespace``).
The pattern is duplicated here so this package stays importable without
archetype installed; ``tests/test_tenancy.py`` pins the parity when
archetype is present.
"""

from __future__ import annotations

import re

SAFE_NAMESPACE_PATTERN = r"[A-Za-z0-9][A-Za-z0-9_.-]*"
SAFE_NAMESPACE_RE = re.compile(SAFE_NAMESPACE_PATTERN)


def require_safe_tenant_id(tenant_id: str) -> str:
    """Accept one explicit server-owned storage namespace or fail closed."""

    if not SAFE_NAMESPACE_RE.fullmatch(tenant_id):
        raise ValueError("tenant_id must be one safe catalog namespace segment")
    return tenant_id
