"""Provider-neutral verified identity and server-owned actor grants."""

from __future__ import annotations

import json
import os
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol
from urllib.parse import urlsplit
from uuid import UUID

from jwt import InvalidTokenError

from vangelis_gateway.tenancy import require_safe_tenant_id

_ALLOWED_ROLES = frozenset({"viewer", "player", "operator", "admin"})
_MAPPING_ENV = "GATEWAY_PRINCIPAL_MAPPINGS_JSON"
_PROVIDER_ENV = "GATEWAY_IDENTITY_PROVIDER"


class HeaderSource(Protocol):
    """The request-header slice used by identity adapters."""

    def getlist(self, key: str) -> list[str]: ...


class IdentityVerificationError(InvalidTokenError):
    """A credential was missing or could not be verified."""


class UnmappedPrincipalError(LookupError):
    """A valid external identity has no server-owned grant."""


@dataclass(frozen=True)
class ExternalPrincipal:
    """Provider-neutral identity extracted only after credential verification."""

    issuer: str
    subject: str = field(repr=False)
    claims: Mapping[str, Any] = field(repr=False)


class IdentityVerifier(Protocol):
    """Request authentication adapter selected explicitly at deployment."""

    @property
    def issuer(self) -> str: ...

    def authenticate(self, headers: HeaderSource) -> ExternalPrincipal: ...


@dataclass(frozen=True)
class PrincipalGrant:
    """Stable internal authority loaded from private server configuration."""

    issuer: str
    subject: str = field(repr=False)
    actor_id: str
    tenant_id: str
    storage_namespace: str
    roles: frozenset[str]


class PrincipalMappings:
    """Exact ``(issuer, subject)`` to stable actor/tenant/role bindings."""

    def __init__(self, entries: Sequence[PrincipalGrant]) -> None:
        if not entries:
            raise ValueError("at least one principal mapping is required")
        by_external: dict[tuple[str, str], PrincipalGrant] = {}
        by_actor: dict[str, PrincipalGrant] = {}
        for index, entry in enumerate(entries):
            key = (entry.issuer, entry.subject)
            if key in by_external:
                raise ValueError(
                    f"principal mapping {index} duplicates an external identity"
                )
            try:
                actor_key = str(UUID(entry.actor_id))
            except ValueError as error:
                raise ValueError(
                    f"principal mapping {index} actor_id must be a UUID"
                ) from error
            prior = by_actor.get(actor_key)
            if prior is not None and (
                prior.tenant_id != entry.tenant_id
                or prior.storage_namespace != entry.storage_namespace
                or prior.roles != entry.roles
            ):
                raise ValueError(
                    f"principal mapping {index} gives one actor conflicting authority"
                )
            by_external[key] = entry
            by_actor.setdefault(actor_key, entry)
        tenant_namespaces: dict[str, str] = {}
        namespace_tenants: dict[str, str] = {}
        for index, entry in enumerate(entries):
            prior_namespace = tenant_namespaces.setdefault(
                entry.tenant_id, entry.storage_namespace
            )
            if prior_namespace != entry.storage_namespace:
                raise ValueError(
                    f"principal mapping {index} gives one tenant conflicting storage"
                )
            prior_tenant = namespace_tenants.setdefault(
                entry.storage_namespace, entry.tenant_id
            )
            if prior_tenant != entry.tenant_id:
                raise ValueError(
                    f"principal mapping {index} shares storage across different tenants"
                )
        self._by_external = by_external

    @property
    def grants(self) -> tuple[PrincipalGrant, ...]:
        """Immutable server-owned authority snapshot for native ingress grants."""
        return tuple(self._by_external.values())

    @classmethod
    def from_json(cls, value: str) -> PrincipalMappings:
        try:
            raw = json.loads(value)
        except (TypeError, json.JSONDecodeError) as error:
            raise ValueError("principal mappings must be valid JSON") from error
        if not isinstance(raw, list):
            raise ValueError("principal mappings must be a JSON array")
        return cls(tuple(_parse_grant(item, index) for index, item in enumerate(raw)))

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> PrincipalMappings:
        env = os.environ if env is None else env
        value = env.get(_MAPPING_ENV)
        if not value:
            raise RuntimeError(f"missing required environment variable: {_MAPPING_ENV}")
        try:
            return cls.from_json(value)
        except ValueError as error:
            raise RuntimeError(f"invalid {_MAPPING_ENV}: {error}") from error

    def resolve(self, principal: ExternalPrincipal) -> PrincipalGrant:
        try:
            return self._by_external[(principal.issuer, principal.subject)]
        except KeyError:
            raise UnmappedPrincipalError("verified principal is not mapped") from None

    def require_issuer(self, issuer: str) -> None:
        if not any(
            mapped_issuer == issuer for mapped_issuer, _subject in self._by_external
        ):
            raise RuntimeError(
                "principal mappings contain no entry for the active issuer"
            )


def identity_components_from_env(
    env: Mapping[str, str] | None = None,
) -> tuple[IdentityVerifier, PrincipalMappings]:
    """Load one explicit provider and its private server-owned grants."""

    env = os.environ if env is None else env
    provider = env.get(_PROVIDER_ENV)
    if not provider:
        raise RuntimeError(f"missing required environment variable: {_PROVIDER_ENV}")
    if provider == "workos_authkit":
        from vangelis_gateway.authkit import AuthKitVerifier

        verifier: IdentityVerifier = AuthKitVerifier.from_env(env)
    elif provider == "cloudflare_access":
        from vangelis_gateway.cloudflare_access import CloudflareAccessVerifier

        verifier = CloudflareAccessVerifier.from_env(env)
    else:
        raise RuntimeError(
            f"invalid {_PROVIDER_ENV}: expected 'workos_authkit' or 'cloudflare_access'"
        )
    mappings = PrincipalMappings.from_env(env)
    mappings.require_issuer(verifier.issuer)
    return verifier, mappings


def _parse_grant(value: object, index: int) -> PrincipalGrant:
    if not isinstance(value, dict):
        raise ValueError(f"principal mapping {index} must be an object")
    expected = {
        "issuer",
        "subject",
        "actor_id",
        "tenant_id",
        "storage_namespace",
        "roles",
    }
    if set(value) != expected:
        raise ValueError(
            f"principal mapping {index} must contain exactly {sorted(expected)}"
        )

    issuer = _nonempty_string(value["issuer"], "issuer", index)
    parsed_issuer = urlsplit(issuer)
    if (
        parsed_issuer.scheme != "https"
        or not parsed_issuer.netloc
        or parsed_issuer.query
        or parsed_issuer.fragment
    ):
        raise ValueError(f"principal mapping {index} issuer must be an HTTPS URL")
    subject = _nonempty_string(value["subject"], "subject", index)
    actor_id = _nonempty_string(value["actor_id"], "actor_id", index)
    try:
        actor_id = str(UUID(actor_id))
    except ValueError as error:
        raise ValueError(
            f"principal mapping {index} actor_id must be a UUID"
        ) from error
    tenant_id = _nonempty_string(value["tenant_id"], "tenant_id", index)
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}", tenant_id):
        raise ValueError(f"principal mapping {index} tenant_id has an invalid format")
    storage_namespace = require_safe_tenant_id(
        _nonempty_string(value["storage_namespace"], "storage_namespace", index)
    )

    raw_roles = value["roles"]
    if not isinstance(raw_roles, list) or not raw_roles:
        raise ValueError(f"principal mapping {index} roles must be a non-empty array")
    if not all(isinstance(role, str) and role for role in raw_roles):
        raise ValueError(
            f"principal mapping {index} roles must contain non-empty strings"
        )
    if len(set(raw_roles)) != len(raw_roles):
        raise ValueError(f"principal mapping {index} roles must not contain duplicates")
    roles = frozenset(raw_roles)
    unknown = roles - _ALLOWED_ROLES
    if unknown:
        raise ValueError(f"principal mapping {index} contains an unknown role")
    return PrincipalGrant(
        issuer=issuer,
        subject=subject,
        actor_id=actor_id,
        tenant_id=tenant_id,
        storage_namespace=storage_namespace,
        roles=roles,
    )


def _nonempty_string(value: object, field_name: str, index: int) -> str:
    if not isinstance(value, str) or not value or value != value.strip():
        raise ValueError(
            f"principal mapping {index} {field_name} must be a non-empty trimmed string"
        )
    return value
