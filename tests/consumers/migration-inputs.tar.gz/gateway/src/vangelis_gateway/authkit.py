"""WorkOS AuthKit bearer-token verification.

Cleanroom implementation against the public AuthKit contract: access tokens
are RS256 JWTs verified offline against the environment's JWKS endpoint.
No WorkOS SDK and no per-request network calls beyond the cached JWKS fetch.

Configuration is explicit URLs so the verifier is not coupled to one
provider's URL conventions. ``AuthKitVerifier.from_env`` reads:

- ``AUTHKIT_JWKS_URL`` (required): JWKS endpoint for the environment
- ``AUTHKIT_ISSUER`` (required): expected ``iss`` claim
- ``AUTHKIT_AUDIENCE`` (optional): expected ``aud`` claim; unchecked when unset
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Protocol

import jwt
from jwt import InvalidTokenError, PyJWKClient
from jwt.exceptions import PyJWKClientError

from vangelis_gateway._jwks import RateLimitedJWKClient
from vangelis_gateway.identity import (
    ExternalPrincipal,
    HeaderSource,
    IdentityVerificationError,
)

__all__ = ["AuthKitVerifier", "VerifiedPrincipal", "InvalidTokenError"]

# Static allowlist: rejects `none` and HS*-with-public-key confusion attacks.
_ALLOWED_ALGORITHMS = ["RS256"]


class SigningKeySource(Protocol):
    """The slice of ``PyJWKClient`` the verifier depends on."""

    def get_signing_key_from_jwt(self, token: str) -> Any: ...


@dataclass(frozen=True)
class VerifiedPrincipal(ExternalPrincipal):
    """Claims the gateway trusts after signature verification."""

    organization_id: str | None
    session_id: str | None


class AuthKitVerifier:
    """Verifies bearer tokens and extracts the principal."""

    def __init__(
        self,
        *,
        jwks_url: str | None = None,
        issuer: str,
        audience: str | None = None,
        leeway_seconds: float = 30.0,
        jwk_client: SigningKeySource | None = None,
    ) -> None:
        if jwk_client is None:
            if not jwks_url:
                raise ValueError("either jwks_url or jwk_client is required")
            jwk_client = RateLimitedJWKClient(
                PyJWKClient(
                    jwks_url,
                    cache_keys=False,
                    cache_jwk_set=True,
                    lifespan=300,
                    timeout=5,
                )
            )
        self._jwks = jwk_client
        self._issuer = issuer
        self._audience = audience
        self._leeway = leeway_seconds

    @property
    def issuer(self) -> str:
        return self._issuer

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> AuthKitVerifier:
        env = os.environ if env is None else env
        missing = [
            key for key in ("AUTHKIT_JWKS_URL", "AUTHKIT_ISSUER") if not env.get(key)
        ]
        if missing:
            raise RuntimeError(
                f"missing required environment variables: {', '.join(missing)}"
            )
        return cls(
            jwks_url=env["AUTHKIT_JWKS_URL"],
            issuer=env["AUTHKIT_ISSUER"],
            audience=env.get("AUTHKIT_AUDIENCE") or None,
        )

    def verify(self, token: str) -> VerifiedPrincipal:
        """Return the verified principal or raise ``InvalidTokenError``.

        Signature, ``exp``/``iat`` (with leeway), ``iss``, and — when
        configured — ``aud`` are all enforced; ``sub`` is required.
        """
        key = self._jwks.get_signing_key_from_jwt(token)
        claims = jwt.decode(
            token,
            getattr(key, "key", key),
            algorithms=_ALLOWED_ALGORITHMS,
            issuer=self._issuer,
            audience=self._audience,
            leeway=self._leeway,
            options={
                "require": ["exp", "iat", "sub"],
                "verify_aud": self._audience is not None,
            },
        )
        subject = claims.get("sub")
        if not isinstance(subject, str) or not subject:
            raise InvalidTokenError("sub claim must be a non-empty string")
        organization = claims.get("org_id")
        session = claims.get("sid")
        return VerifiedPrincipal(
            issuer=self._issuer,
            subject=subject,
            claims=claims,
            organization_id=organization
            if isinstance(organization, str) and organization
            else None,
            session_id=session if isinstance(session, str) and session else None,
        )

    def authenticate(self, headers: HeaderSource) -> VerifiedPrincipal:
        """Require exactly one well-formed bearer credential and verify it."""

        values = headers.getlist("Authorization")
        if len(values) != 1:
            raise IdentityVerificationError(
                "exactly one Authorization header is required"
            )
        value = values[0]
        scheme, separator, token = value.partition(" ")
        if (
            scheme.lower() != "bearer"
            or not separator
            or not token
            or token != token.strip()
            or "," in token
            or len(token.encode("utf-8")) > 16_384
        ):
            raise IdentityVerificationError("invalid Authorization header")
        try:
            return self.verify(token)
        except (InvalidTokenError, PyJWKClientError) as error:
            raise IdentityVerificationError(
                "AuthKit token verification failed"
            ) from error
