# vangelis-gateway

Gateway authenticates an external identity and maps its exact verified issuer and subject to an operator-configured actor, tenant, storage namespace and explicit role grants. JWT claims never select storage or grant roles.

The runtime extra selects `archetype-ecs[analysis,transports]==0.7.0`. Each immutable tenant namespace has one native Archetype server owner. Python server configuration pins resources and physical directories; HTTP `/invoke` and MCP `/mcp` share its closed operation contract and authentication. Eviction and shutdown run through a retained supervisor task, so SDK lifetime remains in one task and failed native close retries the same owner.

Set `GATEWAY_IDENTITY_PROVIDER` to `cloudflare_access` or `workos_authkit`, configure that provider's issuer/audience/JWKS settings, and set `GATEWAY_PRINCIPAL_MAPPINGS_JSON`. Existing credential-free JWT signature, expiry, issuer, audience, rotation and mapping contracts remain applicable. `GATEWAY_STORAGE_URI` is now an operator-owned local directory, with separate `GATEWAY_AUDIT_URI`; `GATEWAY_MAX_ACTIVE_TENANTS` defaults to four. Native library, driver and resource allowlists come from `ServerConfig.from_env()`. Transport audit records are tenant-pinned observations, not another admission ledger.

The current MCP transport enforces loopback hosts/origins. Use an explicitly configured loopback backend for this migration; external deployment and R2 hosting are separate work and are not established by these tests. No listener, real provider credentials or deployment is needed for the synthetic contract suite.

`compatibility/0.6/tests` preserves previous dispatcher hosting tests. They require their matched older Archetype environment and cannot reactivate that owner in the 0.7 server. The current installed tests cover HTTP/MCP authorization, isolated tenant storage/audit, malformed requests, failed-close retries and eviction/shutdown across tasks.
