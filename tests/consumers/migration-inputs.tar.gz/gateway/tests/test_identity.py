"""Provider-neutral identity mapping and startup configuration."""

from __future__ import annotations

import json
from typing import Any

import pytest

from vangelis_gateway.cloudflare_access import CloudflareAccessVerifier
from vangelis_gateway.identity import (
    ExternalPrincipal,
    PrincipalMappings,
    UnmappedPrincipalError,
    identity_components_from_env,
)

CF_ISSUER = "https://lake.cloudflareaccess.com"
WORKOS_ISSUER = "https://api.workos.test/sso"
ACTOR_ID = "018f78ce-4d3e-7c2a-9f10-5b8e8f4c7d6a"


def grant(**overrides: Any) -> dict[str, Any]:
    value: dict[str, Any] = {
        "issuer": CF_ISSUER,
        "subject": "cf-user-stable",
        "actor_id": ACTOR_ID,
        "tenant_id": "lake-alpha",
        "storage_namespace": "lake-alpha-storage",
        "roles": ["admin"],
    }
    value.update(overrides)
    return value


def directory(*entries: dict[str, Any]) -> PrincipalMappings:
    return PrincipalMappings.from_json(json.dumps(list(entries)))


def test_exact_external_identity_resolves_server_owned_authority() -> None:
    mappings = directory(grant())
    resolved = mappings.resolve(
        ExternalPrincipal(issuer=CF_ISSUER, subject="cf-user-stable", claims={})
    )
    assert resolved.actor_id == ACTOR_ID
    assert resolved.tenant_id == "lake-alpha"
    assert resolved.storage_namespace == "lake-alpha-storage"
    assert resolved.roles == frozenset({"admin"})


def test_unmapped_valid_identity_fails_without_registration() -> None:
    mappings = directory(grant())
    with pytest.raises(UnmappedPrincipalError):
        mappings.resolve(
            ExternalPrincipal(issuer=CF_ISSUER, subject="other", claims={})
        )


def test_two_providers_can_alias_one_stable_internal_actor() -> None:
    mappings = directory(
        grant(),
        grant(issuer=WORKOS_ISSUER, subject="workos-user-stable"),
    )
    cf = mappings.resolve(
        ExternalPrincipal(issuer=CF_ISSUER, subject="cf-user-stable", claims={})
    )
    workos = mappings.resolve(
        ExternalPrincipal(issuer=WORKOS_ISSUER, subject="workos-user-stable", claims={})
    )
    assert (cf.actor_id, cf.tenant_id, cf.storage_namespace, cf.roles) == (
        workos.actor_id,
        workos.tenant_id,
        workos.storage_namespace,
        workos.roles,
    )


@pytest.mark.parametrize(
    "entries",
    [
        [grant(), grant()],
        [grant(), grant(issuer=WORKOS_ISSUER, subject="w", roles=["viewer"])],
        [
            grant(),
            grant(
                issuer=WORKOS_ISSUER,
                subject="w",
                actor_id=ACTOR_ID.replace("-", "").upper(),
                roles=["viewer"],
            ),
        ],
        [grant(), grant(issuer=WORKOS_ISSUER, subject="w", storage_namespace="other")],
        [
            grant(),
            grant(
                issuer=WORKOS_ISSUER,
                subject="w",
                actor_id="028f78ce-4d3e-7c2a-9f10-5b8e8f4c7d6a",
                tenant_id="other-tenant",
            ),
        ],
    ],
)
def test_mapping_collisions_fail_startup(entries: list[dict[str, Any]]) -> None:
    with pytest.raises(ValueError, match="mapping"):
        directory(*entries)


@pytest.mark.parametrize(
    "bad",
    [
        grant(actor_id="not-a-uuid"),
        grant(roles=[]),
        grant(roles=["owner"]),
        grant(storage_namespace="../../victim"),
        grant(tenant_id="bad tenant"),
        {**grant(), "email": "not-authority@example.test"},
    ],
)
def test_invalid_mapping_fields_fail_closed_without_echoing_values(
    bad: dict[str, Any],
) -> None:
    with pytest.raises(ValueError) as excinfo:
        directory(bad)
    message = str(excinfo.value)
    assert "not-authority@example.test" not in message
    assert "../../victim" not in message


def test_mapping_requires_nonempty_array_and_active_issuer() -> None:
    with pytest.raises(ValueError, match="at least one"):
        directory()
    with pytest.raises(RuntimeError, match="active issuer"):
        directory(grant()).require_issuer(WORKOS_ISSUER)


def test_principal_repr_omits_subject_and_claims() -> None:
    principal = ExternalPrincipal(
        issuer=CF_ISSUER,
        subject="secret-subject",
        claims={"email": "private@example.test"},
    )
    rendered = repr(principal)
    assert "secret-subject" not in rendered
    assert "private@example.test" not in rendered


def test_explicit_cloudflare_provider_loads_with_matching_mapping() -> None:
    verifier, mappings = identity_components_from_env(
        {
            "GATEWAY_IDENTITY_PROVIDER": "cloudflare_access",
            "CLOUDFLARE_ACCESS_TEAM_DOMAIN": "lake.cloudflareaccess.com",
            "CLOUDFLARE_ACCESS_AUD": "app-aud",
            "GATEWAY_PRINCIPAL_MAPPINGS_JSON": json.dumps([grant()]),
        }
    )
    assert isinstance(verifier, CloudflareAccessVerifier)
    mappings.require_issuer(CF_ISSUER)


@pytest.mark.parametrize(
    "env",
    [
        {},
        {"GATEWAY_IDENTITY_PROVIDER": "unknown"},
        {"GATEWAY_IDENTITY_PROVIDER": "cloudflare_access"},
        {
            "GATEWAY_IDENTITY_PROVIDER": "cloudflare_access",
            "CLOUDFLARE_ACCESS_TEAM_DOMAIN": "https://lake.cloudflareaccess.com/path",
            "CLOUDFLARE_ACCESS_AUD": "aud",
        },
        {
            "GATEWAY_IDENTITY_PROVIDER": "cloudflare_access",
            "CLOUDFLARE_ACCESS_TEAM_DOMAIN": "attacker.example",
            "CLOUDFLARE_ACCESS_AUD": "aud",
        },
    ],
)
def test_missing_or_contradictory_provider_configuration_fails_startup(
    env: dict[str, str],
) -> None:
    with pytest.raises(RuntimeError):
        identity_components_from_env(env)
