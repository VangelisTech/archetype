"""Offline verification tests: static key source, no network."""

from __future__ import annotations

import time
from typing import Any

import jwt
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from starlette.datastructures import Headers
from vangelis_gateway.authkit import AuthKitVerifier, InvalidTokenError
from vangelis_gateway.identity import IdentityVerificationError

ISSUER = "https://issuer.test/env_123"
AUDIENCE = "client_123"


@pytest.fixture(scope="module")
def keypair() -> tuple[Any, Any]:
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return private_key, private_key.public_key()


class StaticKeySource:
    """Stands in for PyJWKClient; always returns the test public key."""

    def __init__(self, public_key: Any) -> None:
        self.key = public_key

    def get_signing_key_from_jwt(self, token: str) -> StaticKeySource:
        return self


def make_token(
    private_key: Any, *, drop: set[str] | None = None, **overrides: Any
) -> str:
    now = int(time.time())
    claims: dict[str, Any] = {
        "iss": ISSUER,
        "sub": "user_01TESTSUBJECT",
        "iat": now,
        "exp": now + 300,
        "sid": "session_01TEST",
    }
    claims.update(overrides)
    for name in drop or set():
        claims.pop(name, None)
    return jwt.encode(claims, private_key, algorithm="RS256")


def verifier_for(public_key: Any, *, audience: str | None = None) -> AuthKitVerifier:
    return AuthKitVerifier(
        issuer=ISSUER, audience=audience, jwk_client=StaticKeySource(public_key)
    )


def test_valid_token_yields_principal(keypair: tuple[Any, Any]) -> None:
    private_key, public_key = keypair
    token = make_token(private_key, org_id="org_01TESTORG")
    principal = verifier_for(public_key).verify(token)
    assert principal.issuer == ISSUER
    assert principal.subject == "user_01TESTSUBJECT"
    assert principal.organization_id == "org_01TESTORG"
    assert principal.session_id == "session_01TEST"
    assert principal.claims["iss"] == ISSUER


def test_personal_session_has_no_organization(keypair: tuple[Any, Any]) -> None:
    private_key, public_key = keypair
    principal = verifier_for(public_key).verify(make_token(private_key))
    assert principal.organization_id is None


def test_expired_token_rejected(keypair: tuple[Any, Any]) -> None:
    private_key, public_key = keypair
    stale = int(time.time()) - 3600
    token = make_token(private_key, iat=stale, exp=stale + 60)
    with pytest.raises(InvalidTokenError):
        verifier_for(public_key).verify(token)


def test_wrong_issuer_rejected(keypair: tuple[Any, Any]) -> None:
    private_key, public_key = keypair
    token = make_token(private_key, iss="https://attacker.test")
    with pytest.raises(InvalidTokenError):
        verifier_for(public_key).verify(token)


def test_missing_sub_rejected(keypair: tuple[Any, Any]) -> None:
    private_key, public_key = keypair
    token = make_token(private_key, drop={"sub"})
    with pytest.raises(InvalidTokenError):
        verifier_for(public_key).verify(token)


def test_audience_enforced_when_configured(keypair: tuple[Any, Any]) -> None:
    private_key, public_key = keypair
    verifier = verifier_for(public_key, audience=AUDIENCE)
    with pytest.raises(InvalidTokenError):
        verifier.verify(make_token(private_key))  # no aud claim
    with pytest.raises(InvalidTokenError):
        verifier.verify(make_token(private_key, aud="other_client"))
    assert verifier.verify(make_token(private_key, aud=AUDIENCE)).subject


def test_algorithm_confusion_rejected(keypair: tuple[Any, Any]) -> None:
    """HS256 token signed with the public key bytes must not verify.

    PyJWT itself refuses to *encode* such a token, so the forgery is
    hand-rolled to make sure the verifier (not the library's encoder) is
    what rejects it.
    """
    import base64
    import hashlib
    import hmac
    import json

    _, public_key = keypair
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    def b64url(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

    now = int(time.time())
    header = b64url(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    payload = b64url(
        json.dumps(
            {"iss": ISSUER, "sub": "user_forged", "iat": now, "exp": now + 300}
        ).encode()
    )
    signing_input = f"{header}.{payload}".encode()
    signature = b64url(hmac.new(public_pem, signing_input, hashlib.sha256).digest())
    forged = f"{header}.{payload}.{signature}"
    with pytest.raises(InvalidTokenError):
        verifier_for(public_key).verify(forged)


def test_garbage_token_rejected(keypair: tuple[Any, Any]) -> None:
    _, public_key = keypair
    with pytest.raises(InvalidTokenError):
        verifier_for(public_key).verify("not-a-jwt")


def test_from_env_requires_configuration() -> None:
    with pytest.raises(RuntimeError, match="AUTHKIT_JWKS_URL"):
        AuthKitVerifier.from_env(env={})
    verifier = AuthKitVerifier.from_env(
        env={"AUTHKIT_JWKS_URL": "https://issuer.test/jwks", "AUTHKIT_ISSUER": ISSUER}
    )
    assert isinstance(verifier, AuthKitVerifier)


def test_request_authentication_requires_exactly_one_bearer_header(
    keypair: tuple[Any, Any],
) -> None:
    private_key, public_key = keypair
    active = verifier_for(public_key)
    token = make_token(private_key)
    principal = active.authenticate(Headers({"Authorization": f"Bearer {token}"}))
    assert principal.subject == "user_01TESTSUBJECT"
    for headers in (
        Headers(),
        Headers({"Authorization": "Basic abc"}),
        Headers({"Authorization": "Bearer "}),
    ):
        with pytest.raises(IdentityVerificationError):
            active.authenticate(headers)


def test_request_authentication_rejects_duplicate_authorization(
    keypair: tuple[Any, Any],
) -> None:
    private_key, public_key = keypair
    token = make_token(private_key)
    headers = Headers(
        raw=[
            (b"authorization", f"Bearer {token}".encode()),
            (b"authorization", f"Bearer {token}".encode()),
        ]
    )
    with pytest.raises(IdentityVerificationError):
        verifier_for(public_key).authenticate(headers)
