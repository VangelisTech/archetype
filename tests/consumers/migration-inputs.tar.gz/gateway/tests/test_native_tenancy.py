"""Consumer-specific tenant authority and retained-close contracts."""

from contextlib import asynccontextmanager
from dataclasses import replace
from types import SimpleNamespace
import asyncio
import json
import os
from pathlib import Path
import pytest
import httpx2
from archetype.api import ServerConfig
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client
from archetype.api.config import ContextResource
from vangelis_gateway.app import create_gateway_app
from vangelis_gateway.identity import ExternalPrincipal, PrincipalGrant, PrincipalMappings
from vangelis_gateway.tenancy_runtime import TenantRuntimeRegistry

TOKEN = "test-only-verified-credential-with-adequate-length"
ISSUER = "https://synthetic.example"
A = PrincipalGrant(
    ISSUER,
    "a",
    "018f4b70-9c00-7000-8000-000000000001",
    "tenant_a",
    "storage_a",
    frozenset({"admin"}),
)
B = PrincipalGrant(
    ISSUER,
    "b",
    "018f4b70-9c00-7000-8000-000000000002",
    "tenant_b",
    "storage_b",
    frozenset({"viewer"}),
)


class Verifier:
    issuer = ISSUER

    def authenticate(self, headers):
        token = headers.get("authorization", "").removeprefix("Bearer ")
        if token == TOKEN:
            return ExternalPrincipal(ISSUER, "a", {})
        if token == TOKEN + "b":
            return ExternalPrincipal(ISSUER, "b", {})
        raise ValueError("invalid credential")


def config():
    return ServerConfig(
        tuple(
            {
                "library": os.environ["ARCHETYPE_NATIVE_LIBRARY"],
                "store": "/operator-template",
                "registry": None,
                "builds": None,
                "driver": None,
            }.items()
        ),
        (ContextResource("files", "files", "main"),),
        (),
    )


def registry(tmp_path, **kwargs):
    return TenantRuntimeRegistry(
        base_storage_uri=tmp_path / "data",
        audit_storage_uri=tmp_path / "audit",
        template=config(),
        verifier=Verifier(),
        mappings=PrincipalMappings((A, B)),
        **kwargs,
    )


@pytest.mark.asyncio
async def test_real_native_tenant_storage_audit_denial_and_malformed_paths(tmp_path):
    r = registry(tmp_path)
    app = create_gateway_app(Verifier(), PrincipalMappings((A, B)), r)
    raw = {
        "version": 1,
        "operation": "publish_context",
        "resource": "files",
        "arguments": {"source_resource": None},
    }
    async with app.router.lifespan_context(app):
        async with httpx2.AsyncClient(
            transport=httpx2.ASGITransport(app), base_url="http://127.0.0.1"
        ) as client:
            unauth = await client.post("/invoke", json=raw)
            assert unauth.status_code == 401 and not r._entries
            a = await client.post("/invoke", json=raw, headers={"Authorization": "Bearer " + TOKEN})
            assert a.status_code == 200, a.text
            denied = await client.post(
                "/invoke", json=raw, headers={"Authorization": "Bearer " + TOKEN + "b"}
            )
            assert denied.status_code == 403, denied.text
            read = dict(raw, operation="read_context", arguments={})
            cold = await client.post(
                "/invoke", json=read, headers={"Authorization": "Bearer " + TOKEN}
            )
            assert cold.status_code == 200
            hidden = await client.post(
                "/invoke", json=read, headers={"Authorization": "Bearer " + TOKEN + "b"}
            )
            assert hidden.status_code != 200
            malicious = dict(raw, arguments={"source_resource": None, "store": "/client-storage"})
            bad = await client.post(
                "/invoke", json=malicious, headers={"Authorization": "Bearer " + TOKEN}
            )
            assert bad.status_code == 400
            assert str(tmp_path) not in a.text and "/client-storage" not in bad.text
            for token, expected in ((TOKEN, cold.json()), (TOKEN + "b", None)):
                async with httpx2.AsyncClient(
                    transport=httpx2.ASGITransport(app), base_url="http://127.0.0.1",
                    headers={"Authorization": "Bearer " + token},
                ) as mcp_http:
                    async with streamable_http_client(
                        "http://127.0.0.1/mcp", http_client=mcp_http
                    ) as (reader, writer):
                        async with ClientSession(reader, writer, read_timeout_seconds=5) as session:
                            await session.initialize()
                            result = await session.call_tool("simulation", {"request_json": json.dumps(read)})
                            value = result.structured_content
                            if expected is not None:
                                assert value == expected
                            else:
                                assert value["ok"] is False

    assert r.storage_for("storage_a") != r.storage_for("storage_b")
    for grant in (A, B):
        rows = [
            json.loads(line)
            for line in r.audit_storage_for(grant.storage_namespace).read_text().splitlines()
        ]
        assert rows and all(
            row["tenant_id"] == grant.tenant_id and row["actor_id"] == grant.actor_id
            for row in rows
        )
    assert not hasattr(r, "dispatcher_for")


class FakeApp:
    def __init__(self, **kwargs):
        self.config = kwargs["config"]
        self.closes = 0
        self.fail = False
        self.state = SimpleNamespace(aclose=self.close)
        self.router = SimpleNamespace(lifespan_context=self.lifespan)

    async def close(self):
        self.closes += 1
        if self.fail:
            raise RuntimeError("close retained")

    @asynccontextmanager
    async def lifespan(self, app):
        yield


@pytest.mark.asyncio
async def test_eviction_and_shutdown_keep_failed_owner_for_retry(tmp_path):
    r = registry(tmp_path, max_active=1, app_factory=FakeApp)
    first = await r.app_for(A)
    first.fail = True
    with pytest.raises(RuntimeError, match="retained"):
        await r.app_for(B)
    assert r._entries[A.tenant_id].app is first
    first.fail = False
    second = await r.app_for(B)
    assert first.closes == 2 and list(r._entries) == [B.tenant_id]
    second.fail = True
    with pytest.raises(RuntimeError):
        await r.shutdown()
    assert r._entries[B.tenant_id].app is second
    second.fail = False
    await r.shutdown()
    assert not r._entries
    with pytest.raises(RuntimeError, match="change"):
        await r.app_for(replace(A, storage_namespace="changed"))
    with pytest.raises(RuntimeError, match="different"):
        await r.app_for(replace(A, tenant_id="new", storage_namespace=B.storage_namespace))


@pytest.mark.asyncio
async def test_real_sdk_first_use_eviction_and_shutdown_in_different_tasks(tmp_path):
    r = registry(tmp_path, max_active=1)
    first = await asyncio.create_task(r.app_for(A))
    first_task = r._entries[A.tenant_id].task
    assert not first_task.done()
    second = await asyncio.create_task(r.app_for(B))
    assert first is not second and first_task.done()
    second_task = r._entries[B.tenant_id].task
    await asyncio.create_task(r.shutdown())
    assert second_task.done() and not r._entries


@pytest.mark.asyncio
async def test_cancelled_shutdown_retry_joins_retained_close_future(tmp_path):
    class HeldClose(FakeApp):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.entered, self.release = asyncio.Event(), asyncio.Event()
        async def close(self):
            self.closes += 1
            self.entered.set()
            await self.release.wait()
    r = registry(tmp_path, app_factory=HeldClose)
    owner = await r.app_for(A)
    supervisor = r._entries[A.tenant_id].task
    first = asyncio.create_task(r.shutdown())
    await owner.entered.wait()
    first.cancel()
    with pytest.raises(asyncio.CancelledError):
        await first
    retry = asyncio.create_task(r.shutdown())
    await asyncio.sleep(0)
    assert owner.closes == 1 and not supervisor.done()
    owner.release.set()
    await asyncio.wait_for(retry, 2)
    assert owner.closes == 1 and supervisor.done() and not r._entries
