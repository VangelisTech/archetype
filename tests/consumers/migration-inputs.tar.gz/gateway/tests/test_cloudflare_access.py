"""Cloudflare Access verification with generated keys and synthetic tenants."""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from threading import Event
from typing import Any

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from jwt.exceptions import PyJWKClientError
from starlette.datastructures import Headers

from vangelis_gateway._jwks import RateLimitedJWKClient
from vangelis_gateway.cloudflare_access import (
    ACCESS_ASSERTION_HEADER,
    CloudflareAccessVerifier,
)
from vangelis_gateway.identity import IdentityVerificationError

ISSUER = "https://lake.cloudflareaccess.com"
AUDIENCE = "synthetic-access-app-aud"
KID = "synthetic-key-1"


@pytest.fixture(scope="module")
def keys() -> tuple[Any, Any, Any, Any]:
    first = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    second = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return first, first.public_key(), second, second.public_key()


class MutableKeySource:
    def __init__(self, available: dict[str, Any]) -> None:
        self.available = available
        self.calls = 0

    def get_signing_key_from_jwt(self, token: str) -> Any:
        self.calls += 1
        kid = jwt.get_unverified_header(token).get("kid")
        try:
            return self.available[kid]
        except KeyError:
            raise PyJWKClientError("synthetic unknown key") from None


class FailingKeySource:
    def get_signing_key_from_jwt(self, token: str) -> Any:
        del token
        raise OSError("synthetic JWKS outage")


class SnapshotKey:
    def __init__(self, key_id: str) -> None:
        self.key_id = key_id


class SnapshotSource:
    def __init__(self, snapshots: list[list[SnapshotKey] | Exception]) -> None:
        self.snapshots = snapshots
        self.calls: list[bool] = []

    def get_signing_keys(self, *, refresh: bool = False) -> list[SnapshotKey]:
        self.calls.append(refresh)
        result = self.snapshots.pop(0)
        if isinstance(result, Exception):
            raise result
        return result


def make_token(
    private_key: Any,
    *,
    kid: str = KID,
    algorithm: str = "RS256",
    drop: set[str] | None = None,
    header_overrides: dict[str, Any] | None = None,
    **overrides: Any,
) -> str:
    now = int(time.time())
    claims: dict[str, Any] = {
        "iss": ISSUER,
        "aud": [AUDIENCE],
        "sub": "synthetic-cf-subject",
        "iat": now - 5,
        "nbf": now - 5,
        "exp": now + 300,
        "type": "app",
        "email": "display-only@example.test",
    }
    claims.update(overrides)
    for name in drop or set():
        claims.pop(name, None)
    headers: dict[str, Any] = {"kid": kid, "typ": "JWT"}
    headers.update(header_overrides or {})
    return jwt.encode(claims, private_key, algorithm=algorithm, headers=headers)


def verifier(source: Any, *, leeway: float = 0) -> CloudflareAccessVerifier:
    return CloudflareAccessVerifier(
        issuer=ISSUER,
        audience=AUDIENCE,
        jwk_client=source,
        leeway_seconds=leeway,
    )


def test_valid_official_shape_yields_only_external_identity(
    keys: tuple[Any, ...],
) -> None:
    private, public, _, _ = keys
    token = make_token(private, role="admin", tenant="attacker-selected")
    principal = verifier(MutableKeySource({KID: public})).verify(token)
    assert principal.issuer == ISSUER
    assert principal.subject == "synthetic-cf-subject"
    assert principal.claims["email"] == "display-only@example.test"
    assert not hasattr(principal, "roles")
    assert not hasattr(principal, "tenant_id")


def test_valid_cloudflare_shape_may_omit_optional_typ(
    keys: tuple[Any, ...],
) -> None:
    private, public, _, _ = keys
    token = make_token(private, header_overrides={"typ": None})
    principal = verifier(MutableKeySource({KID: public})).verify(token)
    assert principal.subject == "synthetic-cf-subject"


def test_request_requires_exactly_one_nonempty_assertion(keys: tuple[Any, ...]) -> None:
    private, public, _, _ = keys
    active = verifier(MutableKeySource({KID: public}))
    with pytest.raises(IdentityVerificationError):
        active.authenticate(Headers())
    with pytest.raises(IdentityVerificationError):
        active.authenticate(Headers({ACCESS_ASSERTION_HEADER: ""}))
    token = make_token(private)
    duplicate = Headers(
        raw=[
            (ACCESS_ASSERTION_HEADER.lower().encode(), token.encode()),
            (ACCESS_ASSERTION_HEADER.lower().encode(), token.encode()),
        ]
    )
    with pytest.raises(IdentityVerificationError):
        active.authenticate(duplicate)


@pytest.mark.parametrize("token", ["not-a-jwt", "a.b", "a.b.c"])
def test_malformed_assertion_rejected(token: str, keys: tuple[Any, ...]) -> None:
    _, public, _, _ = keys
    with pytest.raises(IdentityVerificationError):
        verifier(MutableKeySource({KID: public})).verify(token)


def test_unknown_key_and_jwks_failure_fail_closed(keys: tuple[Any, ...]) -> None:
    private, _, _, _ = keys
    token = make_token(private, kid="unknown")
    with pytest.raises(IdentityVerificationError):
        verifier(MutableKeySource({})).verify(token)
    with pytest.raises(IdentityVerificationError):
        verifier(FailingKeySource()).verify(token)


def test_disallowed_algorithm_and_header_profile_rejected(
    keys: tuple[Any, ...],
) -> None:
    private, public, _, _ = keys
    source = MutableKeySource({KID: public})
    with pytest.raises(IdentityVerificationError):
        verifier(source).verify(make_token(private, algorithm="RS512"))
    with pytest.raises(IdentityVerificationError):
        verifier(source).verify(make_token(private, header_overrides={"typ": "at+jwt"}))
    with pytest.raises(IdentityVerificationError):
        verifier(source).verify(make_token(private, header_overrides={"kid": ""}))


def test_invalid_signature_rejected(keys: tuple[Any, ...]) -> None:
    _, first_public, second_private, _ = keys
    forged = make_token(second_private)
    with pytest.raises(IdentityVerificationError):
        verifier(MutableKeySource({KID: first_public})).verify(forged)


def test_expired_and_not_yet_valid_tokens_rejected(keys: tuple[Any, ...]) -> None:
    private, public, _, _ = keys
    active = verifier(MutableKeySource({KID: public}))
    now = int(time.time())
    with pytest.raises(IdentityVerificationError):
        active.verify(make_token(private, iat=now - 120, nbf=now - 120, exp=now - 60))
    with pytest.raises(IdentityVerificationError):
        active.verify(make_token(private, iat=now + 120, nbf=now + 120, exp=now + 300))


@pytest.mark.parametrize(
    "overrides",
    [
        {"iss": "https://attacker.cloudflareaccess.com"},
        {"aud": ["wrong-aud"]},
        {"aud": [AUDIENCE, "second-aud"]},
        {"aud": AUDIENCE},
    ],
)
def test_wrong_issuer_or_nonexact_audience_rejected(
    overrides: dict[str, Any],
    keys: tuple[Any, ...],
) -> None:
    private, public, _, _ = keys
    with pytest.raises(IdentityVerificationError):
        verifier(MutableKeySource({KID: public})).verify(
            make_token(private, **overrides)
        )


@pytest.mark.parametrize("claim", ["iss", "aud", "sub", "exp", "iat", "nbf", "type"])
def test_every_required_claim_is_enforced(claim: str, keys: tuple[Any, ...]) -> None:
    private, public, _, _ = keys
    with pytest.raises(IdentityVerificationError):
        verifier(MutableKeySource({KID: public})).verify(
            make_token(private, drop={claim})
        )


@pytest.mark.parametrize(
    "overrides",
    [
        {"sub": "", "type": "app"},
        {"sub": "", "type": "service"},
        {"type": "service"},
        {"exp": float(int(time.time()) + 300)},
    ],
)
def test_nonhuman_or_malformed_claim_profile_rejected(
    overrides: dict[str, Any],
    keys: tuple[Any, ...],
) -> None:
    private, public, _, _ = keys
    with pytest.raises(IdentityVerificationError):
        verifier(MutableKeySource({KID: public})).verify(
            make_token(private, **overrides)
        )


def test_key_rotation_accepts_new_kid_and_outage_during_rotation_rejects(
    keys: tuple[Any, ...],
) -> None:
    first_private, first_public, second_private, second_public = keys
    source = MutableKeySource({"old": first_public})
    active = verifier(source)
    assert active.verify(make_token(first_private, kid="old")).subject
    source.available = {"new": second_public}
    assert active.verify(make_token(second_private, kid="new")).subject
    source.available = {}
    with pytest.raises(IdentityVerificationError):
        active.verify(make_token(first_private, kid="removed"))
    assert source.calls == 3


def test_production_jwks_client_bounds_unknown_key_refresh_and_allows_rotation() -> (
    None
):
    clock = [0.0]
    old = SnapshotKey("old")
    new = SnapshotKey("new")
    source = SnapshotSource([[old], [new]])
    client = RateLimitedJWKClient(
        source,
        lifespan=300,
        refresh_cooldown=30,
        clock=lambda: clock[0],
    )

    def header_token(kid: str) -> str:
        return jwt.encode(
            {},
            "synthetic-key-at-least-thirty-two-bytes",
            algorithm="HS256",
            headers={"kid": kid},
        )

    with pytest.raises(PyJWKClientError, match="unknown"):
        client.get_signing_key_from_jwt(header_token("random-attacker-kid"))
    assert client.get_signing_key_from_jwt(header_token("old")) is old
    with pytest.raises(PyJWKClientError, match="cooling down"):
        client.get_signing_key_from_jwt(header_token("another-attacker-kid"))
    assert source.calls == [False]

    clock[0] = 31
    assert client.get_signing_key_from_jwt(header_token("new")) is new
    assert source.calls == [False, True]


def test_jwks_refresh_failure_preserves_fresh_known_keys_without_retry_storm() -> None:
    clock = [0.0]
    old = SnapshotKey("old")
    source = SnapshotSource([[old], OSError("synthetic outage")])
    client = RateLimitedJWKClient(
        source,
        lifespan=300,
        refresh_cooldown=30,
        clock=lambda: clock[0],
    )

    def header_token(kid: str) -> str:
        return jwt.encode(
            {},
            "synthetic-key-at-least-thirty-two-bytes",
            algorithm="HS256",
            headers={"kid": kid},
        )

    assert client.get_signing_key_from_jwt(header_token("old")) is old
    clock[0] = 31
    with pytest.raises(OSError, match="synthetic outage"):
        client.get_signing_key_from_jwt(header_token("unknown"))
    assert client.get_signing_key_from_jwt(header_token("old")) is old
    with pytest.raises(PyJWKClientError, match="cooling down"):
        client.get_signing_key_from_jwt(header_token("another-unknown"))
    assert source.calls == [False, True]


def test_concurrent_unknown_keys_fail_without_waiting_for_the_network_refresh() -> None:
    started = Event()
    release = Event()

    class BlockingSource:
        calls = 0

        def get_signing_keys(self, *, refresh: bool = False) -> list[SnapshotKey]:
            del refresh
            self.calls += 1
            started.set()
            if not release.wait(timeout=2):
                raise TimeoutError("synthetic test refresh was not released")
            return [SnapshotKey("known")]

    def header_token(kid: str) -> str:
        return jwt.encode(
            {},
            "synthetic-key-at-least-thirty-two-bytes",
            algorithm="HS256",
            headers={"kid": kid},
        )

    source = BlockingSource()
    client = RateLimitedJWKClient(source)
    with ThreadPoolExecutor(max_workers=1) as pool:
        first = pool.submit(
            client.get_signing_key_from_jwt,
            header_token("first-unknown"),
        )
        assert started.wait(timeout=1)
        with pytest.raises(PyJWKClientError, match="already in progress"):
            client.get_signing_key_from_jwt(header_token("second-unknown"))
        release.set()
        with pytest.raises(PyJWKClientError, match="unknown"):
            first.result(timeout=1)
    assert source.calls == 1
