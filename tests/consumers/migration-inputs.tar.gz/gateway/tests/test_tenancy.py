"""Server-owned tenant/storage namespace validation."""

from __future__ import annotations

import pytest

from vangelis_gateway.tenancy import SAFE_NAMESPACE_RE, require_safe_tenant_id


@pytest.mark.parametrize("tenant_id", ["lake-alpha", "tenant_01", "a.b", "Z9"])
def test_accepts_safe_configured_tenant_ids(tenant_id: str) -> None:
    assert require_safe_tenant_id(tenant_id) == tenant_id
    assert SAFE_NAMESPACE_RE.fullmatch(tenant_id)


@pytest.mark.parametrize("tenant_id", ["", "../../etc", "has space", "/root", "bad!"])
def test_rejects_unsafe_configured_tenant_ids(tenant_id: str) -> None:
    with pytest.raises(ValueError, match="safe catalog namespace"):
        require_safe_tenant_id(tenant_id)


