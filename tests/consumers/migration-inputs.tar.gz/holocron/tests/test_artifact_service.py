"""Native artifact-only collection and cold typed-index contracts."""

from __future__ import annotations
import asyncio
import json
import wave
from pathlib import Path
import pytest
from archetype import ArtifactSource, RuntimeOperationError
from holocron.artifact_service import ArtifactService


@pytest.mark.asyncio
async def test_cold_collection_exact_retry_and_new_occurrence(tmp_path):
    original = tmp_path / "discussion.md"
    original.write_bytes(b"# Discussion\nA sourced note.\n")
    state = tmp_path / "state"
    source = ArtifactSource(source_uri=str(original), logical_path="notes/discussion.md")
    service = ArtifactService(state, "discussion")
    prepared = await service.prepare(source)
    first = (await service.publish(prepared))[0]
    binding = json.loads(service._binding.read_text())
    assert binding["version"] == 2
    original.unlink()
    reopened = ArtifactService(state, "discussion")
    assert (await reopened.publish(prepared))[0] == first
    facts = dict((await reopened.occurrences()).items[0].common)
    assert facts["logical_path"] == "notes/discussion.md" and facts["sha256"] == first.sha256
    assert "object_uri" not in facts
    rows = (await reopened.artifacts()).to_pydict()
    assert rows["artifact_id"] == [first.artifact_id] and rows["media_family"] == ["text"]
    original.write_bytes(b"# Discussion\nA sourced note.\n")
    second = (await reopened.ingest(source))[0]
    assert second.artifact_id != first.artifact_id and second.sha256 == first.sha256
    assert json.loads(reopened._binding.read_text()) == binding
    assert set((await reopened.artifacts()).to_pydict()["artifact_id"]) == {
        first.artifact_id,
        second.artifact_id,
    }


@pytest.mark.asyncio
async def test_missing_source_has_no_published_occurrence(tmp_path):
    service = ArtifactService(tmp_path / "state", "discussion")
    with pytest.raises(RuntimeOperationError):
        await service.ingest(
            ArtifactSource(source_uri=str(tmp_path / "missing.pdf"), logical_path="missing.pdf")
        )
    assert (await service.occurrences()).total == 0


@pytest.mark.asyncio
async def test_audio_cold_facts_and_concurrent_exact_retry(tmp_path):
    recording = tmp_path / "meeting.wav"
    with wave.open(str(recording), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(16000)
        output.writeframes(b"\0\0" * 8000)
    service = ArtifactService(tmp_path / "state", "meeting")
    prepared = await service.prepare(
        ArtifactSource(source_uri=str(recording), logical_path="audio/meeting.wav")
    )
    first, second = await asyncio.wait_for(
        asyncio.gather(
            service.publish(prepared),
            ArtifactService(tmp_path / "state", "meeting").publish(prepared),
        ),
        timeout=20,
    )
    assert first == second
    recording.unlink()
    reopened = ArtifactService(tmp_path / "state", "meeting")
    page = await reopened.occurrences()
    assert page.total == 1
    facts = dict(page.items[0].facts("audio"))
    assert facts["sample_rate"] == 16000 and facts["duration_seconds"] == 0.5
    audio = (await reopened.index("artifact_audio")).to_pydict()
    assert (
        audio["artifact_id"] == [first[0].artifact_id]
        and audio["sample_rate"] == [16000]
        and audio["duration_seconds"] == [0.5]
    )


@pytest.mark.asyncio
async def test_legacy_binding_fails_without_reinterpreting_storage(tmp_path):
    service = ArtifactService(tmp_path / "state", "discussion")
    service._binding.parent.mkdir(parents=True)
    service._binding.write_text(
        json.dumps(
            {
                "version": 1,
                "collection": "discussion",
                "world_id": "018f4b70-9c00-7000-8000-000000000001",
            }
        )
    )
    before = service._binding.read_bytes()
    with pytest.raises(ValueError, match="matched 0.6"):
        await service.occurrences()
    assert (
        service._binding.read_bytes() == before
        and not (service.state_dir / "native-storage").exists()
    )


@pytest.mark.asyncio
async def test_prepared_target_cannot_cross_collections(tmp_path):
    source = tmp_path / "note.txt"
    source.write_text("bounded evidence")
    first = ArtifactService(tmp_path / "state", "first")
    second = ArtifactService(tmp_path / "state", "second")
    prepared = await first.prepare(ArtifactSource(source_uri=str(source)))
    other = await second.prepare(ArtifactSource(source_uri=str(source)))
    with pytest.raises(ValueError):
        await second.publish(prepared)
    assert (await second.occurrences()).total == 0
    await second.publish(other)
    assert (await first.occurrences()).total == 0 and (await second.occurrences()).total == 1


@pytest.mark.asyncio
async def test_binding_rename_then_failed_directory_sync_is_refenced_on_retry(
    tmp_path, monkeypatch
):
    import os
    import stat

    service = ArtifactService(tmp_path / "state", "discussion")
    source = tmp_path / "note.txt"
    source.write_text("durable binding evidence")
    fsync = os.fsync
    injected = False

    def fail_directory(fd):
        nonlocal injected
        if stat.S_ISDIR(os.fstat(fd).st_mode) and service._binding.exists() and not injected:
            injected = True
            raise OSError("injected directory fence failure")
        return fsync(fd)

    monkeypatch.setattr(os, "fsync", fail_directory)
    with pytest.raises(OSError, match="fence failure"):
        await service.prepare(ArtifactSource(source_uri=str(source)))
    binding = service._binding.read_bytes()
    assert injected and not (service.state_dir / "native-storage").exists()
    fences = []

    def record(fd):
        fences.append(stat.S_ISDIR(os.fstat(fd).st_mode))
        return fsync(fd)

    monkeypatch.setattr(os, "fsync", record)
    prepared = await ArtifactService(tmp_path / "state", "discussion").prepare(
        ArtifactSource(source_uri=str(source))
    )
    assert service._binding.read_bytes() == binding
    assert fences[:2] == [False, True]
    await service.publish(prepared)
    assert (await service.occurrences()).total == 1
