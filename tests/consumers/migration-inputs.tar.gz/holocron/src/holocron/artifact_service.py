# Copyright 2026 Vangelis Technologies Inc.
# SPDX-License-Identifier: Apache-2.0
"""Stable local collections through the supported native artifact workflow."""

from __future__ import annotations

import asyncio
import fcntl
import json
import os
import re
import stat
import tempfile
from contextlib import asynccontextmanager
from pathlib import Path

from archetype import ArchetypeRuntime, ArtifactSource, PreparedArtifacts
from uuid_utils import UUID, uuid7

_COLLECTION = re.compile(r"^[a-z][a-z0-9_-]{0,39}$")


class ArtifactService:
    """Artifact-only collections; no simulation, program, or synthetic ticks."""

    def __init__(self, state_dir: Path, collection: str) -> None:
        if not _COLLECTION.fullmatch(collection):
            raise ValueError("collection must be a lowercase portable slug")
        self.state_dir = Path(state_dir).expanduser().resolve()
        self.collection = collection
        self._binding = self.state_dir / "collections" / f"{collection}.json"
        self._lock = self.state_dir / "collections" / f"{collection}.lock"

    def _acquire(self):
        self.state_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.state_dir, 0o700)
        directory = self._binding.parent
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(directory, 0o700)
        flags = os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(self._lock, flags, 0o600)
        try:
            if not stat.S_ISREG(os.fstat(fd).st_mode):
                raise ValueError("collection lock is not a regular file")
            fcntl.flock(fd, fcntl.LOCK_EX)
            return fd
        except BaseException:
            os.close(fd)
            raise

    @asynccontextmanager
    async def _locked(self):
        acquisition = asyncio.create_task(asyncio.to_thread(self._acquire))
        cancellation = None
        while not acquisition.done():
            try:
                await asyncio.shield(acquisition)
            except asyncio.CancelledError as error:
                cancellation = error
        fd = acquisition.result()
        try:
            if cancellation is not None:
                raise cancellation
            yield
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    def _fence_binding(self):
        fd = os.open(self._binding, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        try:
            if not stat.S_ISREG(os.fstat(fd).st_mode):
                raise ValueError("collection binding is not a regular file")
            os.fsync(fd)
        finally:
            os.close(fd)
        directory_fd = os.open(
            self._binding.parent,
            os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0),
        )
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)

    def _world_id(self, *, create: bool) -> str:
        if self._binding.exists():
            if self._binding.is_symlink():
                raise ValueError("collection binding must not be a symlink")
            binding = json.loads(self._binding.read_text())
            if type(binding) is not dict:
                raise ValueError("collection binding is invalid")
            if binding.get("version") == 1:
                raise ValueError(
                    "Version 1 is a 0.6 collection; use the matched 0.6 reader and explicit migration"
                )
            if (
                type(binding) is not dict
                or set(binding) != {"version", "collection", "world_id"}
                or binding["version"] != 2
                or binding["collection"] != self.collection
            ):
                raise ValueError("collection binding is invalid")
            identifier = UUID(binding["world_id"])
            world_id = str(identifier)
            if world_id != binding["world_id"] or identifier.version != 7:
                raise ValueError("collection identity must be canonical UUIDv7")
            self._fence_binding()
            return world_id
        if not create:
            raise FileNotFoundError("collection has not been created")
        world_id = str(uuid7())
        payload = json.dumps(
            {"version": 2, "collection": self.collection, "world_id": world_id}, sort_keys=True
        ).encode()
        fd, name = tempfile.mkstemp(prefix=f".{self.collection}-", dir=self._binding.parent)
        temporary = Path(name)
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self._binding)
            self._fence_binding()
        finally:
            temporary.unlink(missing_ok=True)
        return world_id

    def _runtime(self):
        return ArchetypeRuntime(store=self.state_dir / "native-storage", storage_only=True)

    @staticmethod
    def _name(world_id):
        return "collection_" + world_id.replace("-", "")

    async def prepare(self, *sources: ArtifactSource) -> PreparedArtifacts:
        """Retain this exact preparation when retrying publication."""
        if not sources or any(type(source) is not ArtifactSource for source in sources):
            raise ValueError("prepare requires exact ArtifactSource values")
        async with self._locked():
            world_id = self._world_id(create=True)
            async with self._runtime() as runtime:
                collection = runtime.artifacts(self._name(world_id))
                await collection.publish()
                return await collection.prepare_files(tuple(sources))

    async def publish(self, prepared: PreparedArtifacts):
        async with self._locked():
            world_id = self._world_id(create=False)
            async with self._runtime() as runtime:
                return await runtime.artifacts(self._name(world_id)).publish_files(prepared)

    async def ingest(self, *sources: ArtifactSource):
        """New ingestion creates new occurrence IDs; use prepare/publish for exact retry."""
        return await self.publish(await self.prepare(*sources))

    async def occurrences(self, *, offset=0, limit=32):
        async with self._locked():
            world_id = self._world_id(create=False)
            async with self._runtime() as runtime:
                return await runtime.artifacts(self._name(world_id)).occurrences(
                    offset=offset, limit=limit
                )

    async def artifacts(self, *, offset=0, limit=32):
        """Outside-runtime analysis of one bounded common-index page."""
        async with self._locked():
            world_id = self._world_id(create=False)
            async with self._runtime() as runtime:
                return await runtime.artifacts(self._name(world_id)).analyze(
                    offset=offset, limit=limit
                )

    async def index(self, table_name: str, *, offset=0, limit=32):
        index = table_name.removeprefix("artifact_")
        if index not in {"files", "audio", "image", "video", "pdf", "code", "table", "diff"}:
            raise ValueError("Unknown typed artifact index")
        async with self._locked():
            world_id = self._world_id(create=False)
            async with self._runtime() as runtime:
                return await runtime.artifacts(self._name(world_id)).analyze(
                    index=index, offset=offset, limit=limit
                )


__all__ = ["ArtifactService"]
