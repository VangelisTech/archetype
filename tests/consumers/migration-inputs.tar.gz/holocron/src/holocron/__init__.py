# Copyright 2026 Vangelis Technologies Inc.
# SPDX-License-Identifier: Apache-2.0
"""Owner-local knowledge services; heavy artifact and legacy APIs load on demand."""

from importlib import import_module

_CORE = {"ArtifactService": "holocron.artifact_service"}

_LEGACY = {
    "FixtureBookmarkExportAdapter": "holocron.bookmarks",
    "AdmittedSnapshot": "holocron.ingestors",
    "IngestorError": "holocron.ingestors",
    "ProjectionPlan": "holocron.ingestors",
    "ProjectionRow": "holocron.ingestors",
    "ProviderCheckpoint": "holocron.ingestors",
    "ProviderIdentity": "holocron.ingestors",
    "SnapshotCoverage": "holocron.ingestors",
    "SnapshotPoll": "holocron.ingestors",
    "SnapshotProjector": "holocron.ingestors",
    "SourceIngestor": "holocron.ingestors",
    "SourceSnapshot": "holocron.ingestors",
    "HolocronWorldLibrary": "holocron.library",
    "MaterializationReceipt": "holocron.library",
    "TranscriptSource": "holocron.library",
    "WorldInspection": "holocron.library",
    "deterministic_page_deriver": "holocron.library",
    "ArchiveIngestReceipt": "holocron.local_archive",
    "ArchiveSource": "holocron.local_archive",
    "LocalTextArchiveIngestor": "holocron.local_archive",
    "DEFAULT_SYNTHESIS_CONTRACT": "holocron.missions",
    "DEFAULT_SYNTHESIS_TASK": "holocron.missions",
    "ArtifactContextPageMission": "holocron.missions",
    "ChatCompletionsProvider": "holocron.missions",
    "PageMission": "holocron.missions",
    "SynthesisAnchor": "holocron.missions",
    "SynthesisContract": "holocron.missions",
    "SynthesisIdentity": "holocron.missions",
    "SynthesisResult": "holocron.missions",
    "SynthesisTask": "holocron.missions",
    "WikiPageDraft": "holocron.missions",
    "PageCatalog": "holocron.pages",
    "PageCatalogCorruptionError": "holocron.pages",
    "PageRecord": "holocron.pages",
    "PageSearchResult": "holocron.pages",
    "inspect_provider": "holocron.provider_inspection",
    "ContextBundle": "holocron.retrieval",
    "ContextExcerpt": "holocron.retrieval",
    "ContextIntegrityError": "holocron.retrieval",
    "ContextRetriever": "holocron.retrieval",
    "HOLOCRON": "holocron.schema",
    "ArtifactOccurrence": "holocron.schema",
    "Bookmark": "holocron.schema",
    "DerivedFrom": "holocron.schema",
    "ExtractedFrom": "holocron.schema",
    "LibraryInstallation": "holocron.schema",
    "ProviderSyncAttempt": "holocron.schema",
    "SourceDisappearance": "holocron.schema",
    "SourceItemObservation": "holocron.schema",
    "SourceProjectionManifest": "holocron.schema",
    "SourceRevision": "holocron.schema",
    "TranscriptSourceRevision": "holocron.schema",
    "WikiPage": "holocron.schema",
    "WorldLibraryDefinition": "holocron.schema",
    "ProviderInspection": "holocron.sync",
    "ProviderSyncCoordinator": "holocron.sync",
    "ProviderSyncError": "holocron.sync",
    "ProviderSyncReceipt": "holocron.sync",
    "provider_operation_key": "holocron.sync",
    "TranscriptFileIngestor": "holocron.transcripts",
}
__all__ = list(_CORE)


def __getattr__(name: str):
    if name in _CORE:
        value = getattr(import_module(_CORE[name]), name)
        globals()[name] = value
        return value
    if name not in _LEGACY:
        raise AttributeError(name)
    raise RuntimeError("This legacy world-library API requires the matched Holocron/Archetype 0.6 environment; use ArtifactService on 0.7")
