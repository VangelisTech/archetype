# Copyright 2026 Vangelis Technologies Inc.
# SPDX-License-Identifier: Apache-2.0

"""Local operator entrypoint for Holocron's Archetype artifact service."""

from __future__ import annotations

import argparse
import asyncio
import json
from dataclasses import asdict
from pathlib import Path

from archetype import ArtifactSource

from holocron.artifact_service import ArtifactService


async def _run(args: argparse.Namespace) -> None:
    service = ArtifactService(args.state_dir, args.collection)
    if args.command == "ingest":
        refs = await service.ingest(
            ArtifactSource(source_uri=str(args.source.resolve()), logical_path=args.logical_path)
        )
        print(json.dumps([asdict(ref) for ref in refs], sort_keys=True))
    elif args.command == "list":
        print(json.dumps(asdict(await service.occurrences(offset=args.offset, limit=args.limit)), sort_keys=True, default=str))
    elif args.command == "index":
        table = await service.index(args.table_name, offset=args.offset, limit=args.limit)
        print(json.dumps(table.to_pydict(), sort_keys=True, default=str))


def main() -> None:
    parser = argparse.ArgumentParser(description="Holocron Archetype artifact ingestion")
    parser.add_argument("--state-dir", type=Path, required=True)
    parser.add_argument("--collection", required=True)
    commands = parser.add_subparsers(dest="command", required=True)
    ingest = commands.add_parser("ingest", help="Admit an exact file through Archetype's native artifact workflow")
    ingest.add_argument("source", type=Path)
    ingest.add_argument("--logical-path", required=True)
    listing = commands.add_parser("list", help="Read one bounded artifact occurrence page")
    listing.add_argument("--offset", type=int, default=0)
    listing.add_argument("--limit", type=int, default=32)
    index = commands.add_parser("index", help="Read an Archetype typed media index")
    index.add_argument("table_name")
    index.add_argument("--offset", type=int, default=0)
    index.add_argument("--limit", type=int, default=32)
    asyncio.run(_run(parser.parse_args()))


if __name__ == "__main__":
    main()
