# Selected Holocron artifact adapter migration fixture

This fixture packages only the actual selected artifact adapter and its focused contracts against Archetype 0.7. It deliberately omits the independent Holocron memory CLI, unrelated world-library modules and private tools. The package identity is retained for import/metadata behavior; fixture metadata removes the unrelated CLI/data-file contributions. This is migration evidence, not a complete Holocron distribution or a published consumer release. Source module hashes are recorded against the isolated selected-input snapshot.
